﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem15
{
    class problem15LatticePaths
    {
        static void Main(string[] args)
        {
            double path = paths(20, 20);
            Console.WriteLine(path);
            Console.ReadLine();
        }
        public static double paths(int x, int y)
        {
            int row = (x + y);
            int check = (row / 2);
            double ret = nCr(row, check);
            return ret;
        }
        public static double factorial(int num)
        {
            double end = 1;
            for (double i = 1; i < num + 1; i++)
            {
                end *= i;
            }
            return end;
        }
        public static double nCr(int n, int k)
        {
            double ret = factorial(n) / (factorial(k) * factorial(n - k));
            return ret;
        }
        public static double nPr(int n, int k)
        {
            double ret = factorial(n) / factorial(n - k);
            return ret;
        }
    }
}
