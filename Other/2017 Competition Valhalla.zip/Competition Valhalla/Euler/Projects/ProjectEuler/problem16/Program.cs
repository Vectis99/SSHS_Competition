﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace problem16
{
    class problem16PowerDigitSum
    {
        static void Main(string[] args)
        {
            var num = (BigInteger) Math.Pow(2, 1000);
            String input = num.ToString();
            Console.WriteLine(stringSum(input));
            Console.ReadLine();
        }
        public static double stringSum(String var)
        {
            double num = 0;
            for (int i = 0; i < var.Count(); i ++)
            {
                num += int.Parse(var[i].ToString());
            }
            return num;
        }
    }
}
