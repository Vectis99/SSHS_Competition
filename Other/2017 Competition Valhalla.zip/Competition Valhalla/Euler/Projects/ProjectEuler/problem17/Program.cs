﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem17
{
    class problem17NumberLettersCount
    {
        static void Main(string[] args)
        {
            int total = 0;
            for (int i = 1; i < 1001; i ++)
            {
                total += letterCount(i);
            }
            //total = letterCount(911);
            Console.WriteLine(total);
            Console.ReadLine();
        }
        public static int letterCount(int num)
        {
            int ret = 0;
            String number = num.ToString();
            int numberSize = number.Count();
            int oneCheck = int.Parse(number[numberSize - 1].ToString());
            if (numberSize > 1)
            {
                int tenCheck = int.Parse(number[numberSize - 2].ToString());
                if (tenCheck == 1)
                {
                    ret += numLetterTeen(oneCheck);
                }
                else
                {
                    ret += numLetter10s(tenCheck);
                    ret += numLetterBase(oneCheck);
                }
                if (numberSize > 2)
                {
                    int hundredCheck = int.Parse(number[numberSize - 3].ToString());
                    if (hundredCheck != 0)
                    {
                        ret += 7;
                        ret += numLetterBase(hundredCheck);
                    }
                    if (oneCheck != 0 || (tenCheck != 0 && oneCheck == 0))
                    {
                        ret += 3;
                    }
                    if (numberSize > 3)
                    {
                        int thousandCheck = int.Parse(number[numberSize - 4].ToString());
                        if (thousandCheck != 0)
                        ret += 8;
                        ret += numLetterBase(thousandCheck);
                    }
                }
            }
            else
            {
                ret = numLetterBase(num);
            }
            Console.WriteLine("Num: " + num + " Ret: " + ret);
            return ret;
        }
        public static int numLetterBase(int num)
        {
            int ret = 0;
            if (num == 1 || num == 2 || num == 6)
            {
                ret = 3;
            }
            else if (num == 4 || num == 5 || num == 9)
            {
                ret = 4;
            }
            else if (num == 3 || num == 7 || num == 8)
            {
                ret = 5;
            }
            return ret;
        }
        public static int numLetter10s(int num)
        {
            int ret = 0;
            if (num == 4 || num == 5 || num == 6)
            {
                ret = 5;
            }
            else if (num == 1 || num == 2 || num == 3 || num == 8 || num == 9)
            {
                ret = 6;
            }
            else if (num == 7)
            {
                ret = 7;
            }
            return ret;
        }
        public static int numLetterTeen(int num)
        {
            int ret = 3;
            if (num == 1 || num == 2)
            {
                ret = 6;
            }
            else if (num == 5 || num == 6)
            {
                ret = 7;
            }
            else if (num == 3 || num == 4 || num == 8 || num == 9)
            {
                ret = 8;
            }
            else if (num == 7)
            {
                ret = 9;
            }
            return ret;
        }
        //One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Eleven, Twelve, Thirteen, Fourteen, Fifteen, Sixteen, Seventeen, Eighteen, Nineteen
        //Twenty, Thirty, Fourty, Fifty, Sixty, Seventy, Eighty, Ninety
        //Hundred, Thousand, Million
        //Check point 911
    }
}
