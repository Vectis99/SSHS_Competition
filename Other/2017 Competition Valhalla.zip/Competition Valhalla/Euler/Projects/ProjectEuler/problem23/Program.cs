﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem23
{
    class problem23NonAbundantSums
    {
        static void Main(string[] args)
        {
            List<int> list = getAbundantNum(28123);
            int ans = 0;
            Boolean noSum = true;
            /*foreach(int num in list)
            {
                Console.WriteLine(num);
            }*/
            List<int> sumList = new List<int>();
            for (int f = 0; f < list.Count(); f++)
            {
                for (int s = f; s < list.Count(); s++)
                {
                    sumList.Add(list[s] + list[f]);
                }
            }
            //Console.WriteLine(sumList.Count());
            sumList = sumList.Distinct().ToList();
            /*Console.WriteLine(sumList.Count());
            Console.WriteLine("Got there");
            Console.ReadLine();
            foreach (int num in sumList)
            {
                Console.WriteLine(num);
            }
            Console.ReadLine();
            Console.WriteLine("Survived the merge");*/
            sumList = mergeSort(sumList);
            for (int i = 1; i < 28124; i++)
            {
                for (int j = 0; j < sumList.Count(); j++)
                {
                    if (sumList[j] == i)
                    {
                        noSum = false;
                    }
                    else if (j > 0)
                    {
                        if (sumList[j - 1] < i && sumList[j] > i)
                        {
                            noSum = true;
                            j = sumList.Count();
                        }
                    }
                }
                if (noSum)
                {
                    ans += i;
                    //Console.ReadLine();
                }
                //Finish an i loop
            }
            Console.WriteLine(ans);
            Console.ReadLine();
        }
        public static List<int> getAbundantNum(int num)
        {
            List<int> temp = new List<int>();
            for (int i = 0; i < num + 1; i ++)
            {
                if (i < sumDivisors(i))
                {
                    temp.Add(i);
                    //Console.WriteLine("i: " + i + " sumDivisor: " + sumDivisors(i));
                    //Console.ReadLine();
                }
            }
            return temp;
        }
        public static int sumDivisors(int num)
        {
            int ret = 0;
            for (int i = 1; i < num; i++)
            {
                if (num % i == 0)
                {
                    ret += i;
                }
            }
            return ret;
        }
        public static List<int> mergeSort(List<int> list)
        {
            if (list.Count() > 1)
            {
                int leftCount = 0;
                int rightCount = 0;
                List<int> leftList = new List<int>();
                List<int> rightList = new List<int>();
                for (int i = 0; i < list.Count(); i++)
                {
                    if (i < (list.Count() / 2))
                    {
                        leftList.Add(list[i]);
                    }
                    else
                    {
                        rightList.Add(list[i]);
                    }
                }
                leftList = mergeSort(leftList);
                rightList = mergeSort(rightList);
                List<int> combineList = new List<int>();
                while (leftCount < leftList.Count() || rightCount < rightList.Count())
                {
                    if (leftCount < leftList.Count())
                    {
                        if (rightCount < rightList.Count())
                        {
                            if (leftList[leftCount] < rightList[rightCount])
                            {
                                combineList.Add(leftList[leftCount]);
                                leftCount++;
                            }
                            else
                            {
                                combineList.Add(rightList[rightCount]);
                                rightCount++;
                            }
                        }
                        else
                        {
                            combineList.Add(leftList[leftCount]);
                            leftCount++;
                        }
                    }
                    else
                    {
                        combineList.Add(rightList[rightCount]);
                        rightCount++;
                    }
                }
                return combineList;
            }
            else
            {
                return list;
            }
        }
    }
}
