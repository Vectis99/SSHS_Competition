﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem21
{
    class problem21AmicableNumbers
    {
        static void Main(string[] args)
        {
            int[] list = new int[10001];
            int[] checkList = setZero(10001);
            int sumAmicable = 0;
            for(int i = 1; i < 10001; i++)
            {
                list[i] = sumDivisors(i);
            }
            List<int> amicableList = amicableNum(list, checkList);
            foreach(int num in amicableList)
            {
                sumAmicable += num;
            }
            Console.WriteLine(sumAmicable);
            Console.ReadLine();
        }
        public static int sumDivisors(int num)
        {
            int ret = 0;
            for(int i = 1; i < num; i++)
            {
                if (num%i == 0)
                {
                    ret += i;
                }
            }
            return ret;
        }
        public static int[] setZero(int num)
        {
            int[] ret = new int[num];
            for(int i = 0; i < num; i++)
            {
                ret[i] = 0;
            }
            return ret;
        }
        public static List<int> amicableNum(int[] list, int[] check)
        {
            List<int> ret = new List<int>();
            for(int i = 1; i < 10001; i++)
            {
                if(check[i] == 0)
                {
                    int listNum = list[i];
                    if (listNum < 10001)
                    {
                        if (i == list[listNum] && i != listNum)
                        {
                            ret.Add(i);
                            ret.Add(listNum);
                        }
                        check[i] = 1;
                        check[listNum] = 1;
                    }
                }
            }
            return ret;
        }
    }
}
