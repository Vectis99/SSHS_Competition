﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem5
{
    public class problem5SmallestMultiple
    {
        public static void Main(String[] args)
        {
            double n = 1;
            Boolean cannotDivis = true;
            while (cannotDivis)
            {
                cannotDivis = false;
                for (int i = 1; i < 20; i++)
                {
                    if ((n % i) != 0)
                    {
                        i = 20;
                        cannotDivis = true;
                        n++;
                    }
                }
            }
            Console.WriteLine(n);
            Console.ReadLine();
        }
    }

}
