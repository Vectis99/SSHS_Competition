/**
 * This is an old package which contains a bunch of poorly written garbage.<br>
 * You should probably use any alternative you can think of.<br>
 * Handles a variety of ways judges might input their data.
 * @author South Salem High School
 */

package inputHandler;