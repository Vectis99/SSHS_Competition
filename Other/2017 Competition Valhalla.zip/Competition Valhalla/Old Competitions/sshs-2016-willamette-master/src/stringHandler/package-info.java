/**
 * Easily and quickly break apart strings into useful chunks.
 * @author South Salem High School
 */
package stringHandler;