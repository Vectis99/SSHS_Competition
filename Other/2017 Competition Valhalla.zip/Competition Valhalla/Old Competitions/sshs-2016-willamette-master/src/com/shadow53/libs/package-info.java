/**
 * Michael' (The non-Asian one's) librarys.<br>
 * Thank you for the help!
 * @author Michael [???]
 *
 */
package com.shadow53.libs;