/**
 * Taking potshots on things that might be useful based on past problems.
 * @author South Salem High School
 *
 */
package simulation;