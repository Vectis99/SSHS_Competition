# sshs-2016-willamette
Libraries for usage at the 2016 Willamette programming competition, by South Salem High School

Make changes to this file when you are testing your GitHub interface, whatever that may be.