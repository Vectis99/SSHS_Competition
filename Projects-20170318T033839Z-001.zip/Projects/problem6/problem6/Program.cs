﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem6
{
    public class problem6SumSquareDifference
    {
        public static void Main(String[] args)
        {
            int sumSquare = 0;
            int squareSum = 0;
            for (int i = 0; i < 101; i++)
            {
                sumSquare += (i * i);
            }
            for (int i = 0; i < 101; i++)
            {
                squareSum += i;
            }
            squareSum = (squareSum * squareSum);
            Console.WriteLine(squareSum - sumSquare);
            Console.ReadLine();
        }
    }
}
