﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem9
{
    class problem9SpecialPythagoreanTriplet
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            int c = 0;
            Boolean checkEm = false;
            while (!checkEm)
            {
                if ((a+b+c) == 1000 && a < b && b < c && ((a * a) + (b * b)) == (c * c))
                {
                    checkEm = true;
                }
                else
                {
                    if (c >= (1000-a-b))
                    {
                        if (b > c)
                        {
                            a++;
                            b = 0;
                            c = -1;
                        }
                        else
                        {
                            b++;
                            c = -1;
                        }
                    }
                    c++;
                }
            }
            Console.WriteLine("a: " + a + "\nb: " + b + "\nc: " + c + "\nTotal: " + (a * b * c));
            Console.ReadLine();
        }
    }
}
