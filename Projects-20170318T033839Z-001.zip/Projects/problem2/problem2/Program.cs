﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem2
{
    public class problem2EvenFibonacciNumbers
    {
        public static void Main(String[] args)
        {
            List<int> fibo = new List<int>();
            fibo.Add(1);
            fibo.Add(2);
            Boolean lessThan = true;
            while (lessThan)
            {
                int fiboLength = fibo.Count;
                int next = (fibo[fiboLength - 2] + fibo[fiboLength - 1]);
                if (next < 4000000)
                {
                    fibo.Add(next);
                }
                else
                {
                    lessThan = false;
                }
            }
            int sum = 0;
            while (fibo.Count() != 0)
            {
                int temp = fibo[0];
                fibo.RemoveAt(0);
                if (temp % 2 == 0)
                {
                    sum += temp;
                }
            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
    }

}
