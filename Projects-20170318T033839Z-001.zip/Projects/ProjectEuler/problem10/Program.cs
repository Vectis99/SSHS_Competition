﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem10
{
    class problem10SummationOfPrimes
    {
        static void Main(string[] args)
        {
            List<double> allNum = new List<double>();
            List<bool> numPrime = new List<bool>();
            List<double> prime = new List<double>();
            double checkNum = 0;
            double finalNum = 0;
            bool finalPrime = false;
            double countTo = 2000000;
            for (double i = 2; i <= countTo; i++)
            {
                allNum.Add(i);
                numPrime.Add(true);
            }
            while(!finalPrime)
            {
                if (checkNum == (allNum.Count() - 1))
                {
                    finalPrime = true;
                }
                if (numPrime[(int)checkNum] == true)
                {
                    double tempNum = allNum[(int)checkNum];
                    //Console.WriteLine(tempNum + " " + numPrime[(int)checkNum]);
                    //Console.ReadLine();
                    prime.Add(tempNum);
                    for (double i = (2*tempNum); i <= countTo; i += tempNum)
                    {
                        numPrime[(int) i - 2] = false;
                    }
                    //Console.WriteLine(numPrime[(int)(2*tempNum) - 2]);
                }
                checkNum++;
            }
            foreach (double num in prime)
            {
                finalNum += num;
                //Console.WriteLine(num);
            }
            Console.WriteLine(finalNum);
            Console.ReadLine();
        }
    }
}
