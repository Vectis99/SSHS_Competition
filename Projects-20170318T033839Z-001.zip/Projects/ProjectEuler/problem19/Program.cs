﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem19
{
    class problem19CountingSundays
    {
        static void Main(string[] args)
        {
            int maxYear = 2000;
            int counter = 0;
            int[,] monthYear = new int[13, maxYear + 1];
            monthYear[1, 1901] = 2;
            for(int i = 1901; i < maxYear + 1; i++)
            {
                for (int j = 1; j < 13; j++)
                {
                    switch (j)
                    {
                        case 1:
                            if(i != 1901)
                            {
                                monthYear[1, i] = monthYear[12, i - 1] + (31 % 7);
                            }
                            break;
                        case 3:
                            if ((i % 1000 == 0 && i % 400 == 0) || (i % 1000 != 0 && i % 4 == 0))
                            {
                                monthYear[j, i] = monthYear[j - 1, i] + (29 % 7);
                            }
                            else
                            {
                                monthYear[j, i] = monthYear[j - 1, i] + (28 % 7);
                            }
                            break;
                        case 5:
                        case 7:
                        case 10:
                        case 12:
                            monthYear[j, i] = monthYear[j - 1, i] + (30 % 7);
                            break;
                        default:
                            monthYear[j, i] = monthYear[j - 1, i] + (31 % 7);
                            break;
                    }
                    if (monthYear[j, i] > 7)
                    {
                        monthYear[j, i] = monthYear[j, i] - 7;
                    }
                    if (monthYear[j, i] == 7)
                    {
                        counter++;
                    }
                    Console.WriteLine("Month: " + j + " Year: " + i + " First Day: " + monthYear[j, i]);
                    //Console.ReadLine();
                }
            }
            Console.WriteLine(counter);
            Console.ReadLine();
        }
    }
}
