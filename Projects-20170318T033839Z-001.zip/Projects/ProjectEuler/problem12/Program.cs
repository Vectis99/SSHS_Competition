﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem12
{
    class problem12HighlyDivisibleTriangularNumber
    {
        static void Main(string[] args)
        {
            int count = 1;
            int num = 0;
            bool divisCheck = false;
            while(!divisCheck)
            {
                int divisNum = 2;
                num += count;
                int divisLess = (num/2);
                for (int i = 2; i < divisLess; i ++)
                {
                    if (num%i == 0)
                    {
                        if (i * i == num)
                        {
                            divisNum ++;
                        }
                        else
                        {
                            divisNum += 2;
                        }
                        divisLess = (num / i);
                    }
                }
                if (divisNum > 500)
                {
                    divisCheck = true;
                }
                else
                {
                    count++;
                }
            }
            Console.WriteLine(num);
            Console.ReadLine();
        }
    }
}
