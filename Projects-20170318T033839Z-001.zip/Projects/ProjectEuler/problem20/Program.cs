﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace problem20
{
    class problem20FactorialDigitSum
    {
        static void Main(string[] args)
        {
            var num = (BigInteger)bigFactorial(100);
            String stringNum = num.ToString();
            int sum = 0;
            for(int i = 0; i < stringNum.Count(); i++)
            {
                sum += int.Parse(stringNum[i].ToString());
            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
        public static BigInteger bigFactorial(int num)
        {
            var end = (BigInteger)1;
            for (int i = 1; i < num + 1; i++)
            {
                end *= i;
            }
            return end;
        }
    }
}
