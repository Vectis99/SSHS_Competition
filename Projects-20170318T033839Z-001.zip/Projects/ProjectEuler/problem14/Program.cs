﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem14
{
    class problem14LongestCollatzSequence
    {
        static void Main(string[] args)
        {
            int checkNum = 0;
            int chainMax = 0;
            for (int i = 1; i < 1000000; i ++)
            {
                double temp = i;
                int chainCount = 1;
                while (temp != 1)
                {
                    if (temp%2 == 0)
                    {
                        temp /= 2;
                    }
                    else
                    {
                        temp = ((temp * 3) + 1);
                    }
                    chainCount++;
                }
                if (chainCount > chainMax)
                {
                    chainMax = chainCount;
                    checkNum = i;
                }
            }
            Console.WriteLine(checkNum);
            Console.ReadLine();
        }
    }
}
