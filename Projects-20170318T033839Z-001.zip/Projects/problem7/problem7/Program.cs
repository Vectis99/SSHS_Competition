﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem7
{
    public class problem710001stPrime
    {
        public static void Main(String[] args)
        {
            int n = 2;
            List<int> primeList = new List<int>();
            while (primeList.Count() < 10001)
            {
                Boolean notPrime = false;
                for (int j = 2; j < n; j++)
                {
                    if (n % j == 0 && j != n)
                    {
                        notPrime = true;
                        j = n;
                    }
                }
                if (notPrime == false)
                {
                    primeList.Add(n);
                }
                n++;
            }
            Console.WriteLine("Final: " + primeList[10000]);
            Console.ReadLine();
        }
    }

}
