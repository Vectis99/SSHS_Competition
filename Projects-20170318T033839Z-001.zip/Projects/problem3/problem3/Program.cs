﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem3
{
    public class problem3LargestPrimeFactor
    {
        public static void Main(String[] args)
        {
            double num = 600851475143;
            List<double> primeFactors = new List<double>();
            for (double i = 2; i < Math.Sqrt(num); i ++)
            {
                if ((num%i) == 0)
                {
                    double newNum = (num/i);
                    Boolean prime = true;
                    for (double j = 2; j < (i - 1); j ++)
                    {
                        if ((i%j) == 0)
                        {
                            prime = false;
                            j = i;
                        }
                    }
                    if (prime)
                    {
                        primeFactors.Add(i);
                        foreach (double temp in primeFactors)
                        {
                            Console.WriteLine(temp);
                        }
                    }
                }
            }
            Console.WriteLine("Final Num: " + primeFactors[primeFactors.Count() - 1]);
            Console.ReadLine();
        }
    }
}
