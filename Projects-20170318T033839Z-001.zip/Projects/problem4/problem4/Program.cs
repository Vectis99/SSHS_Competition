﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace problem4
{
    public class problem4LargestPalindromeProduct
    {
        public static void Main(String[] args)
        {
            String tempPalin = "";
            int finalPalinCheck = 0;
            int product1 = 999;
            int product2 = 999;
            Boolean palinOk = false;
            List<int> palindrome = new List<int>();
            List<int> palinCheck = new List<int>();
            List<int> finalPalins = new List<int>();
            while (!palinOk)
            {
                int temp = (product1 * product2);
                int len = temp.ToString().Length;
                for (int i = 0; i < len; i++)
                {
                    palindrome.Insert(0, temp % 10);
                    palinCheck.Add(temp % 10);
                    temp /= 10;
                }
                if (palinCheck.SequenceEqual(palindrome))
                {
                    foreach (int num in palindrome)
                    {
                        tempPalin += num;
                    }
                    finalPalins.Add(int.Parse(tempPalin));
                }
                tempPalin = "";
                palindrome.Clear();
                palinCheck.Clear();
                if (product1 == 100 && product2 == 100)
                {
                    palinOk = true;
                }
                else if (product1 == 100)
                {
                    product1 = 999;
                    product2--;
                }
                else
                {
                    product1--;
                }
            }
            foreach (int temp in finalPalins)
            {
                if (temp > finalPalinCheck)
                {
                    finalPalinCheck = temp;
                }
            }
            Console.WriteLine("Largest Palindrome: " + finalPalinCheck);
            Console.ReadLine();
        }
    }

}
